package tele;

import java.time.LocalDate;

public class TV {
    public String model;
    String trademark;
    private int diagonal;
    private LocalDate date;

    public TV (){

    }

    public TV (String model, String trademark){
        this.model = ("Модель телевизора "+model);
        this.trademark = trademark;
    }

    public String getTrademark() {
        return ("Марка производителя "+trademark);
    }
    public TV (TV original){
        this(original.model, original.trademark);
        this.model = original.model;
        this.trademark = original.trademark;

    }

    public void setTrademark(String trademark) {
        this.trademark = trademark;
    }

    public int getDiagonal() {
        return diagonal;
    }

    public void setDiagonal(int diagonal) {
        this.diagonal = diagonal;
    }

    public LocalDate getDate() {
        return date;
    }

    public void setDate(LocalDate date) {
        this.date = date;
    }
}
