package tele;

import java.time.LocalTime;

public class Factory {
   TV Television = new TV("H4472Y","TOSHIBA");
   private int cost;
   private LocalTime prodTime;
   public TV getTelevision(){
      return Television;

   }
   public void setTelevision(){
      this.Television = Television;
   }

   public int getCost() {
      return cost;
   }

   public void setCost(int cost) {
      this.cost = cost;
   }

   public LocalTime getProdTime() {
      return prodTime;
   }

   public void setProdTime(LocalTime prodTime) {
      this.prodTime = prodTime;
   }
}

